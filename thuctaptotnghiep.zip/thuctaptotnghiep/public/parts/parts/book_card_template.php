<div class="book-card">
    <div class="image-wrapper" style="position: relative;">
        <?php if (!empty($b['cover_url'])): ?>
            <img src="<?= e($b['cover_url']) ?>" alt="" style="height:180px; width: 100%; object-fit: contain;">
        <?php else: ?>
            <img src="<?= base_url('assets/images/no-image.png') ?>" style="height:180px;">
        <?php endif; ?>
        
        <?php if ((int)$b['discount_percent'] > 0): ?>
            <span class="badge-discount" style="position: absolute; top: 5px; right: 5px; background: red; color: white; padding: 2px 5px; font-size: 11px; border-radius: 3px;">
                -<?= (int)$b['discount_percent'] ?>%
            </span>
        <?php endif; ?>
    </div>

    <h3 style="font-size: 16px; margin: 10px 0; height: 40px; overflow: hidden;">
        <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="color: #333;">
            <?= e($b['title']) ?>
        </a>
    </h3>

    <div class="price-section">
        <?php if (book_has_discount($b)): ?>
            <div style="font-size: 13px; color: #888; text-decoration: line-through;">
                <?= money($b['price']) ?>
            </div>
            <div style="font-size: 16px; color: #d0021b; font-weight: bold;">
                <?= money(book_effective_price($b)) ?>
            </div>
        <?php else: ?>
             <div style="font-size: 13px; color: transparent;">.</div> <div style="font-size: 16px; color: #000; font-weight: bold;">
                <?= money($b['price']) ?>
            </div>
        <?php endif; ?>
    </div>
    
    <form method="post" action="<?= base_url('index.php?c=cart&a=add') ?>" style="margin-top: 10px;">
        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
        <button type="submit" style="width: 100%; background: #007bff; color: white; border: none; padding: 5px; border-radius: 4px; cursor: pointer;">
            Thêm vào giỏ
        </button>
    </form>
</div>