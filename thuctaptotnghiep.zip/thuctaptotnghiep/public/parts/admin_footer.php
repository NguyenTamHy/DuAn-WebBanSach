<?php
// public/parts/admin_footer.php
?>
</main>
<footer class="admin-footer wrap">
  <p>Admin • Bookstore</p>
</footer>
</body>
</html>
