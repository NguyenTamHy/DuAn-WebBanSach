<?php
// public/parts/footer.php
?>
</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="ft-left">
      <h3>Bookstore</h3>
      <p>Website demo đồ án - bán sách.</p>
    </div>
    <div class="ft-right">
      <p>&copy; <?= date('Y') ?> Bookstore</p>
    </div>
  </div>
</footer>
</body>
</html>
