// public/assets/js/app.js
console.log('Bookstore app loaded');
