<?php
// app/controllers/CartController.php
require_once __DIR__ . '/../cart.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../models/Book.php';

class CartController
{
    public function index() {
        $cart = cart_detailed();
        render('cart', ['cart' => $cart]);
    }

    public function add() {
        $id  = (int)($_POST['book_id'] ?? 0);
        $qty = (int)($_POST['qty'] ?? 1);

        if ($qty <= 0) {
            $_SESSION['error'] = 'Số lượng phải lớn hơn 0.';
            redirect('index.php?c=cart&a=index');
        }

        if ($id > 0) {
            $book = Book::find($id);
            if (!$book) {
                $_SESSION['error'] = 'Sách không tồn tại.';
            } 
            elseif ((int)$book['stock_qty'] <= 0) {
                $_SESSION['error'] = 'Sách đã hết hàng.';
            } 
            elseif ($qty > (int)$book['stock_qty']) {
                $_SESSION['error'] = 'Kho chỉ còn ' . $book['stock_qty'] . ' cuốn.';
            } 
            else {
                cart_add($id, $qty);
                $_SESSION['message'] = 'Đã thêm vào giỏ hàng!';
            }
        }
        redirect('index.php?c=cart&a=index');
    }

    public function update() {
        foreach ($_POST['qty'] ?? [] as $book_id => $qty) {
            $qty = (int)$qty;
            if ($qty > 0) {
                $book = Book::find((int)$book_id);
                $max = $book ? (int)$book['stock_qty'] : 0;
                if ($qty > $max) $qty = $max;
                cart_update((int)$book_id, $qty);
            } else {
                cart_update((int)$book_id, 0);
            }
        }
        redirect('index.php?c=cart&a=index');
    }

    public function clear() {
        cart_clear();
        redirect('index.php?c=cart&a=index');
    }
}