<?php
// app/controllers/OrderController.php

require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../models/Orders.php';
require_once __DIR__ . '/../models/OrderItem.php';
// BẮT BUỘC THÊM 2 FILE NÀY ĐỂ XỬ LÝ HỦY ĐƠN
require_once __DIR__ . '/../models/Book.php'; 
require_once __DIR__ . '/../db.php'; 

class OrderController
{
    /**
     * Trang: Đơn hàng của tôi
     * URL: index.php?c=order&a=my
     */
    public function my()
    {
        if (!is_logged_in()) {
            redirect('index.php?c=auth&a=login');
        }

        $orders = Order::findByUser(current_user_id(), 20);

        // dùng view app/views/orders_list.php
        render('orders_list', ['orders' => $orders]);
    }

    /**
     * Trang: Chi tiết đơn hàng
     * URL: index.php?c=order&a=detail&id=...
     */
    public function detail()
    {
        if (!is_logged_in()) {
            redirect('index.php?c=auth&a=login');
        }

        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            $_SESSION['error'] = 'ID đơn hàng không hợp lệ.';
            redirect('index.php?c=order&a=my');
        }

        $order = Order::findById($id);
        // Chỉ cho xem đơn hàng của chính mình
        if (!$order || (int)$order['user_id'] !== current_user_id()) {
            $_SESSION['error'] = 'Không tìm thấy đơn hàng.';
            redirect('index.php?c=order&a=my');
        }

        $items = OrderItem::findByOrder($id);

        // dùng view app/views/order_detail.php
        render('order_detail', compact('order', 'items'));
    }

    /**
     * Chức năng: Hủy đơn hàng
     * URL: POST index.php?c=order&a=cancel
     */
    public function cancel()
    {
        // 1. Kiểm tra đăng nhập
        if (!is_logged_in()) {
            redirect('index.php?c=auth&a=login');
        }

        $id = (int)($_POST['order_id'] ?? 0);

        // 2. Kiểm tra đơn hàng có tồn tại và thuộc về user không
        $order = Order::findById($id);
        if (!$order || (int)$order['user_id'] !== current_user_id()) {
            $_SESSION['error'] = 'Đơn hàng không tồn tại hoặc bạn không có quyền truy cập.';
            redirect('index.php?c=order&a=my');
        }

        // 3. Chỉ cho phép hủy khi trạng thái là 'Pending'
        if ($order['status'] !== 'Pending') {
            $_SESSION['error'] = 'Bạn chỉ có thể hủy đơn hàng khi đang ở trạng thái Chờ xử lý.';
            redirect('index.php?c=order&a=detail&id=' . $id);
        }

        // 4. THỰC HIỆN HỦY VÀ HOÀN KHO (Transaction)
        $pdo = db();
        $pdo->beginTransaction();

        try {
            // A. Cập nhật trạng thái đơn hàng thành 'Cancelled'
            Order::updateStatus($id, 'Cancelled');

            // B. Lấy danh sách sản phẩm trong đơn để hoàn lại kho
            $items = OrderItem::findByOrder($id);
            foreach ($items as $item) {
                // Gọi hàm restoreStock trong Model Book
                Book::restoreStock((int)$item['book_id'], (int)$item['qty']);
            }

            // C. Xác nhận thành công
            $pdo->commit();
            $_SESSION['message'] = 'Đã hủy đơn hàng thành công.';

        } catch (Exception $e) {
            // D. Nếu lỗi thì hoàn tác
            $pdo->rollBack();
            $_SESSION['error'] = 'Lỗi hệ thống, không thể hủy đơn hàng lúc này.';
        }

        // Quay lại trang chi tiết đơn hàng
        redirect('index.php?c=order&a=detail&id=' . $id);
    }
}