<?php
// app/controllers/OrderController.php

require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../views/admin/Oders.php';
require_once __DIR__ . '/../models/OrderItem.php';

class OrderController
{
    public function my()
    {
        if (!is_logged_in()) {
            redirect('index.php?c=auth&a=login');
        }

        $orders = Order::findByUser(current_user_id(), 20);
        // Có thể làm view riêng, ở đây tạm reuse order_detail hoặc tạo file mới
        render('order_list', ['orders' => $orders]); // nếu bạn tạo view này
    }

    public function detail()
    {
        if (!is_logged_in()) {
            redirect('index.php?c=auth&a=login');
        }

        $id = (int)($_GET['id'] ?? 0);
        $order = Order::findById($id);
        if (!$order || (int)$order['user_id'] !== current_user_id()) {
            http_response_code(404);
            echo "Order not found";
            exit;
        }

        $items = OrderItem::findByOrder($id);
        render('order_detail', compact('order', 'items'));
    }
}
