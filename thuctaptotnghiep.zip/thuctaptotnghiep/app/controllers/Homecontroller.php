<?php
// app/controllers/HomeController.php
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../models/Book.php';
require_once __DIR__ . '/../models/Category.php';

class HomeController
{
    public function index()
{
    // 1. Lấy các danh mục sách
    $categories = Category::all();
    
    // 2. Tạo mảng chứa sách đã được nhóm theo danh mục
    // Cấu trúc: [ 'Tên DM A' => [DS Sách A], 'Tên DM B' => [DS Sách B] ]
    $booksByCategory = [];

    foreach ($categories as $cat) {
        // Lấy 4 cuốn sách mới nhất thuộc danh mục này
        $books = Book::byCategory((int)$cat['id'], 4);
        
        // Chỉ hiển thị danh mục nào có sách
        if (!empty($books)) {
            $booksByCategory[] = [
                'id'    => $cat['id'],
                'name'  => $cat['name'],
                'books' => $books
            ];
        }
    }

    // Lấy thêm sách giảm giá/bán chạy để hiển thị ở top (nếu muốn giữ lại)
    $discounted   = Book::discounted(5); // Lấy 5 cuốn slider
    $bestSellers  = Book::bestSellers(5);

    // Truyền dữ liệu sang View
    render('home', compact('booksByCategory', 'discounted', 'bestSellers'));
}
    // --- THÊM HÀM NÀY ---
    public function search()
    {
        $keyword = trim($_GET['keyword'] ?? '');
        $books = [];
        
        if ($keyword !== '') {
            // Gọi hàm search trong Model Book
            $books = Book::search($keyword, 0, 20); 
        }

        render('search_results', compact('books', 'keyword'));
    }
}