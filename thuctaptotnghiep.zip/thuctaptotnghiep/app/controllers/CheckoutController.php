<?php
// app/controllers/CheckoutController.php

require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../cart.php';
require_once __DIR__ . '/../models/Orders.php';
require_once __DIR__ . '/../models/OrderItem.php';
// BẮT BUỘC PHẢI CÓ DÒNG NÀY ĐỂ GỌI HÀM TRỪ KHO
require_once __DIR__ . '/../models/Book.php'; 
require_once __DIR__ . '/../db.php'; // Cần để dùng Transaction

class CheckoutController
{
    public function index()
    {
        if (!is_logged_in()) {
            $_SESSION['error'] = 'Bạn cần đăng nhập trước khi thanh toán.';
            redirect('index.php?c=auth&a=login');
        }

        $cart = cart_detailed();
        if (empty($cart['lines'])) {
            $_SESSION['error'] = 'Giỏ hàng trống.';
            redirect('index.php?c=cart&a=index');
        }

        $shipping = 20000;
        $discount = 0;
        $total    = $cart['subtotal'] + $shipping - $discount;

        render('checkout', compact('cart', 'shipping', 'discount', 'total'));
    }

    public function placeOrder()
    {
        // 1. Kiểm tra đăng nhập
        if (!is_logged_in()) {
            $_SESSION['error'] = 'Bạn cần đăng nhập trước khi thanh toán.';
            redirect('index.php?c=auth&a=login');
        }

        $cart = cart_detailed();
        if (empty($cart['lines'])) {
            $_SESSION['error'] = 'Giỏ hàng trống.';
            redirect('index.php?c=cart&a=index');
        }

        // 2. Lấy thông tin
        $name    = trim($_POST['name'] ?? '');
        $phone   = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $payment = $_POST['payment_method'] ?? 'COD';

        if ($name === '' || $phone === '' || $address === '') {
            $_SESSION['error'] = 'Vui lòng nhập đầy đủ thông tin nhận hàng.';
            redirect('index.php?c=checkout&a=index');
        }

        // === BẮT ĐẦU TRANSACTION ĐỂ ĐẢM BẢO AN TOÀN ===
        $pdo = db();
        $pdo->beginTransaction();

        try {
            $shipping = 20000;
            $discount = 0;
            $total    = $cart['subtotal'] + $shipping - $discount;
            
            $addrJson = ['name' => $name, 'phone' => $phone, 'address' => $address];

            // 3. Lưu đơn hàng
            $orderId = Order::create(current_user_id(), $addrJson, $cart['subtotal'], $discount, $shipping, $total, $payment);

            // 4. Lưu chi tiết
            OrderItem::createItems($orderId, $cart['lines']);

            // 5. TRỪ KHO (QUAN TRỌNG NHẤT)
            foreach ($cart['lines'] as $line) {
                $bookId = (int)$line['book']['id'];
                $qtyBuy = (int)$line['qty'];
                $bookTitle = $line['book']['title'];
                
                // Gọi hàm trừ kho. Nếu trả về false (do hết hàng) -> Báo lỗi ngay
                $success = Book::decreaseStock($bookId, $qtyBuy);
                
                if (!$success) {
                    throw new Exception("Sách '$bookTitle' vừa hết hàng hoặc không đủ số lượng!");
                }
            }

            // Mọi thứ OK -> Lưu vào DB
            $pdo->commit();

            cart_clear();
            $_SESSION['message'] = 'Đặt hàng thành công!';
            redirect('index.php?c=order&a=detail&id=' . $orderId);

        } catch (Exception $e) {
            // Có lỗi -> Hủy toàn bộ thao tác
            $pdo->rollBack();
            $_SESSION['error'] = 'Lỗi thanh toán: ' . $e->getMessage();
            redirect('index.php?c=cart&a=index');
        }
    }
}