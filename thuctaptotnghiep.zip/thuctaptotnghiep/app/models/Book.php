<?php
// app/models/Book.php
require_once __DIR__ . '/../db.php';

class Book
{
    // ----------------------------------------------------
    // CÁC HÀM CƠ BẢN (FIND, SEARCH, CATEGORY...)
    // ----------------------------------------------------

    public static function find(int $id): ?array
    {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findMany(array $ids): array
    {
        if (empty($ids)) return [];
        $pdo = db();
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT * FROM books WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        return $stmt->fetchAll();
    }

    public static function categoryIds(int $bookId): array
    {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT category_id FROM book_categories WHERE book_id = ?");
        $stmt->execute([$bookId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    }

    // ----------------------------------------------------
    // CÁC HÀM HIỂN THỊ (LATEST, DISCOUNTED...)
    // ----------------------------------------------------

    public static function latest(int $limit = 8): array {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT * FROM books ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function discounted(int $limit = 8): array {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT * FROM books WHERE discount_percent > 0 ORDER BY discount_percent DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function bestSellers(int $limit = 8): array {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT b.* FROM books b LEFT JOIN order_items oi ON oi.book_id = b.id GROUP BY b.id ORDER BY COUNT(oi.id) DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function byCategory(int $categoryId, int $limit = 12): array {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT b.* FROM books b JOIN book_categories bc ON bc.book_id = b.id WHERE bc.category_id = ? ORDER BY b.created_at DESC LIMIT ?");
        $stmt->bindValue(1, $categoryId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function search(string $keyword = '', int $categoryId = 0, int $limit = 12, int $offset = 0): array {
        $pdo = db();
        $sql = "SELECT DISTINCT b.* FROM books b ";
        if ($categoryId > 0) $sql .= " JOIN book_categories bc ON bc.book_id = b.id ";
        $sql .= " WHERE 1=1 ";
        if ($categoryId > 0) $sql .= " AND bc.category_id = " . (int)$categoryId;
        if (!empty($keyword)) $sql .= " AND (b.title LIKE " . $pdo->quote('%'.$keyword.'%') . ")";
        $sql .= " ORDER BY b.created_at DESC LIMIT $limit OFFSET $offset";
        return $pdo->query($sql)->fetchAll();
    }

    public static function allForAdmin(): array {
        $pdo = db();
        $sql = "SELECT b.*, (SELECT COALESCE(SUM(qty), 0) FROM order_items WHERE book_id = b.id) as sold_qty, (SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE book_id = b.id) as avg_rating, (SELECT GROUP_CONCAT(c.name SEPARATOR ', ') FROM book_categories bc JOIN categories c ON c.id = bc.category_id WHERE bc.book_id = b.id) as category_names FROM books b ORDER BY b.created_at DESC";
        return $pdo->query($sql)->fetchAll();
    }

    // ----------------------------------------------------
    // CÁC HÀM CRUD (CREATE, UPDATE, DELETE)
    // ----------------------------------------------------

    public static function create(array $data, array $categoryIds = []): int {
        $pdo = db();
        $stmt = $pdo->prepare("INSERT INTO books (title, slug, isbn, price, stock_qty, cover_url, description, publisher_id, published_at, discount_percent) VALUES (:title, :slug, :isbn, :price, :stock_qty, :cover_url, :description, :publisher_id, :published_at, :discount_percent)");
        $stmt->execute([
            ':title' => $data['title'], ':slug' => $data['slug']??null, ':isbn' => $data['isbn']??null, 
            ':price' => $data['price'], ':stock_qty' => $data['stock_qty']??0, ':cover_url' => $data['cover_url']??null, 
            ':description' => $data['description']??null, ':publisher_id' => $data['publisher_id']??null, 
            ':published_at' => $data['published_at']??null, ':discount_percent' => $data['discount_percent']??0
        ]);
        $id = (int)$pdo->lastInsertId();
        self::syncCategories($id, $categoryIds);
        return $id;
    }

    public static function updateById(int $id, array $data, array $categoryIds = []): bool {
        $pdo = db();
        $stmt = $pdo->prepare("UPDATE books SET title=:title, slug=:slug, isbn=:isbn, price=:price, stock_qty=:stock_qty, cover_url=:cover_url, description=:description, publisher_id=:publisher_id, published_at=:published_at, discount_percent=:discount_percent WHERE id=:id");
        $stmt->execute([
            ':title' => $data['title'], ':slug' => $data['slug']??null, ':isbn' => $data['isbn']??null, 
            ':price' => $data['price'], ':stock_qty' => $data['stock_qty']??0, ':cover_url' => $data['cover_url']??null, 
            ':description' => $data['description']??null, ':publisher_id' => $data['publisher_id']??null, 
            ':published_at' => $data['published_at']??null, ':discount_percent' => $data['discount_percent']??0, ':id' => $id
        ]);
        self::syncCategories($id, $categoryIds);
        return true;
    }

    public static function deleteById(int $id): bool {
        $pdo = db();
        $pdo->prepare("DELETE FROM book_categories WHERE book_id = ?")->execute([$id]);
        return $pdo->prepare("DELETE FROM books WHERE id = ?")->execute([$id]);
    }

    protected static function syncCategories(int $bookId, array $categoryIds): void {
        $pdo = db();
        $pdo->prepare("DELETE FROM book_categories WHERE book_id = ?")->execute([$bookId]);
        if (empty($categoryIds)) return;
        $stmt = $pdo->prepare("INSERT INTO book_categories (book_id, category_id) VALUES (?, ?)");
        foreach (array_unique($categoryIds) as $cid) {
            $stmt->execute([':book_id' => $bookId, ':category_id' => (int)$cid]);
        }
    }

    // ----------------------------------------------------
    // HÀM TRỪ KHO QUAN TRỌNG (SỬA LẠI ĐỂ TRẢ VỀ TRUE/FALSE)
    // ----------------------------------------------------
    public static function decreaseStock(int $bookId, int $qty): bool
    {
        $pdo = db();
        // Chỉ trừ nếu tồn kho ĐỦ (stock_qty >= qty)
        $stmt = $pdo->prepare("UPDATE books SET stock_qty = stock_qty - :qty WHERE id = :id AND stock_qty >= :qty");
        $stmt->execute([':qty' => $qty, ':id' => $bookId]);
        
        // Nếu có dòng nào được update nghĩa là trừ thành công
        return $stmt->rowCount() > 0;
    }
    public static function restoreStock(int $bookId, int $qty): void
    {
        $pdo = db();
        $stmt = $pdo->prepare("
            UPDATE books 
            SET stock_qty = stock_qty + :qty 
            WHERE id = :id
        ");
        $stmt->execute([
            ':qty' => $qty,
            ':id'  => $bookId
        ]);
    }
}