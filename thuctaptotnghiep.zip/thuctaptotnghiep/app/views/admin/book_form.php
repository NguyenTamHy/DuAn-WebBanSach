<?php
/** @var array $book */
/** @var array $categories */
/** @var array $selectedCategories */
$isEdit = !empty($book['id']);
?>

<style>
    /* CSS RIÊNG CHO FORM ADMIN */
    .admin-form-container {
        background: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        max-width: 900px;
        margin: 0 auto;
    }

    .form-title {
        font-size: 24px;
        color: #333;
        margin-bottom: 25px;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    /* Layout Grid */
    .form-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* Chia 3 cột */
        gap: 20px;
    }

    .full-width {
        grid-column: 1 / -1; /* Chiếm hết chiều ngang */
    }

    .two-thirds {
        grid-column: span 2;
    }

    /* Form Elements */
    .form-group {
        margin-bottom: 5px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
        font-size: 14px;
    }

    .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
        transition: 0.3s;
    }

    .form-control:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
    }

    textarea.form-control {
        resize: vertical;
        min-height: 120px;
    }

    /* Checkbox Categories Style */
    .categories-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        padding: 10px;
        border: 1px solid #eee;
        border-radius: 5px;
        background: #f9f9f9;
    }

    .cat-item {
        display: flex;
        align-items: center;
        background: #fff;
        border: 1px solid #ccc;
        padding: 6px 12px;
        border-radius: 20px;
        cursor: pointer;
        font-size: 13px;
        transition: 0.2s;
    }

    .cat-item:hover {
        border-color: #007bff;
        background: #e3f2fd;
    }

    .cat-item input {
        margin-right: 8px;
        cursor: pointer;
    }

    /* Ảnh bìa */
    .image-preview {
        margin-top: 10px;
        padding: 5px;
        border: 1px solid #ddd;
        border-radius: 5px;
        display: inline-block;
        background: #fff;
    }

    /* Nút bấm */
    .form-actions {
        margin-top: 30px;
        display: flex;
        gap: 15px;
        justify-content: flex-end;
        border-top: 1px solid #eee;
        padding-top: 20px;
    }

    .btn-submit {
        background-color: #007bff;
        color: white;
        padding: 10px 25px;
        border: none;
        border-radius: 5px;
        font-weight: 600;
        cursor: pointer;
        font-size: 15px;
    }
    .btn-submit:hover { background-color: #0056b3; }

    .btn-cancel {
        background-color: #6c757d;
        color: white;
        padding: 10px 25px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: 600;
        font-size: 15px;
        display: inline-block;
    }
    .btn-cancel:hover { background-color: #5a6268; }

    /* Responsive */
    @media (max-width: 768px) {
        .form-grid { grid-template-columns: 1fr; } /* Mobile về 1 cột */
        .full-width, .two-thirds { grid-column: span 1; }
    }
</style>

<div class="admin-form-container">
    <h2 class="form-title"><?= $isEdit ? 'Chỉnh sửa thông tin sách' : 'Thêm sách mới vào kho' ?></h2>

    <form method="post" 
          action="<?= base_url('index.php?c=admin&a=' . ($isEdit ? 'bookUpdate' : 'bookStore')) ?>"
          enctype="multipart/form-data">
        
        <?= csrf_field(); ?>

        <?php if ($isEdit): ?>
            <input type="hidden" name="id" value="<?= (int)$book['id'] ?>">
            <input type="hidden" name="old_cover_url" value="<?= e($book['cover_url'] ?? '') ?>">
        <?php endif; ?>

        <div class="form-grid">
            
            <div class="form-group two-thirds">
                <label>Tiêu đề sách <span style="color:red">*</span></label>
                <input type="text" name="title" class="form-control" value="<?= e($book['title'] ?? '') ?>" required placeholder="Nhập tên sách...">
            </div>

            <div class="form-group">
                <label>Slug (Đường dẫn)</label>
                <input type="text" name="slug" class="form-control" value="<?= e($book['slug'] ?? '') ?>" placeholder="tự động tạo nếu để trống">
            </div>

            <div class="form-group">
                <label>Giá bán (VNĐ) <span style="color:red">*</span></label>
                <input type="number" name="price" class="form-control" min="0" step="1000" value="<?= e($book['price'] ?? 0) ?>" required>
            </div>

            <div class="form-group">
                <label>Số lượng tồn kho</label>
                <input type="number" name="stock_qty" class="form-control" min="0" value="<?= e($book['stock_qty'] ?? 0) ?>">
            </div>

            <div class="form-group">
                <label>Giảm giá (%)</label>
                <input type="number" name="discount_percent" class="form-control" min="0" max="100" value="<?= e($book['discount_percent'] ?? 0) ?>">
            </div>

            <div class="form-group">
                <label>Mã ISBN</label>
                <input type="text" name="isbn" class="form-control" value="<?= e($book['isbn'] ?? '') ?>">
            </div>

            <div class="form-group two-thirds">
                <label>Ngày xuất bản</label>
                <input type="date" name="published_at" class="form-control" value="<?= e($book['published_at'] ?? '') ?>">
            </div>

            <div class="form-group full-width">
                <label>Thể loại</label>
                <div class="categories-wrapper">
                    <?php foreach ($categories as $cat): ?>
                        <label class="cat-item">
                            <input type="checkbox" name="category_ids[]" 
                                   value="<?= (int)$cat['id'] ?>"
                                   <?= in_array($cat['id'], $selectedCategories ?? [], true) ? 'checked' : '' ?>>
                            <?= e($cat['name']) ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group full-width">
                <label>Mô tả chi tiết</label>
                <textarea name="description" class="form-control" placeholder="Nhập nội dung giới thiệu sách..."><?= e($book['description'] ?? '') ?></textarea>
            </div>

            <div class="form-group full-width">
                <label>Ảnh bìa sách</label>
                <input type="file" name="cover" class="form-control" accept="image/*" style="padding: 6px;">
                
                <?php if (!empty($book['cover_url'])): ?>
                    <div style="margin-top: 10px;">
                        <span style="font-size: 12px; color: #666;">Ảnh hiện tại:</span><br>
                        <div class="image-preview">
                            <img src="<?= e($book['cover_url']) ?>" style="height:120px; display: block;">
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        </div> <div class="form-actions">
            <a href="<?= base_url('index.php?c=admin&a=books') ?>" class="btn-cancel">Hủy bỏ</a>
            <button type="submit" class="btn-submit">
                <?= $isEdit ? 'Lưu cập nhật' : 'Thêm sách mới' ?>
            </button>
        </div>

    </form>
</div>