<style>
    /* CSS Giao diện Dashboard Admin */
    .dashboard-container {
        padding: 20px;
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .dashboard-title {
        font-size: 28px;
        color: #333;
        margin-bottom: 30px;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 25px;
    }

    /* Thẻ Card chức năng */
    .dash-card {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        border: 1px solid #eee;
        text-align: center;
        text-decoration: none;
        color: #555;
        transition: transform 0.3s, box-shadow 0.3s;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .dash-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        border-color: #007bff;
    }

    .dash-icon {
        font-size: 48px;
        margin-bottom: 15px;
        display: block;
    }

    .dash-card h3 {
        margin: 0 0 10px 0;
        font-size: 20px;
        color: #333;
    }

    .dash-card p {
        font-size: 14px;
        color: #777;
        margin: 0;
    }

    /* Màu sắc riêng cho từng thẻ */
    .card-books:hover { border-top: 5px solid #17a2b8; }
    .card-orders:hover { border-top: 5px solid #ffc107; }
    .card-home:hover { border-top: 5px solid #28a745; }
</style>

<div class="dashboard-container">
    <h2 class="dashboard-title">Tổng quan quản trị</h2>

    <div class="dashboard-grid">
        
        <a href="<?= base_url('index.php?c=admin&a=books') ?>" class="dash-card card-books">
            <span class="dash-icon">📚</span>
            <h3>Quản lý Sách</h3>
            <p>Thêm, sửa, xóa sách và cập nhật kho hàng</p>
        </a>

        <a href="<?= base_url('index.php?c=admin&a=orders') ?>" class="dash-card card-orders">
            <span class="dash-icon">📦</span>
            <h3>Quản lý Đơn hàng</h3>
            <p>Xem danh sách, duyệt đơn và xử lý vận chuyển</p>
        </a>

        <a href="<?= base_url('index.php') ?>" class="dash-card card-home">
            <span class="dash-icon">🏠</span>
            <h3>Xem Trang Web</h3>
            <p>Quay về giao diện người dùng mua sắm</p>
        </a>

    </div>
</div>