<h2>Admin Dashboard</h2>

<ul>
    <li><a href="<?= base_url('index.php?c=admin&a=books') ?>">Quản lý sách</a></li>
    <!-- sau thêm quản lý đơn hàng, user, stats, v.v. -->
</ul>
