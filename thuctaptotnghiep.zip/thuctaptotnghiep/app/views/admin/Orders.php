<?php /** @var array $orders */ ?>

<style>
    .admin-orders-container {
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .status-badge {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
        color: #fff;
    }
    .st-Pending { background-color: #ffc107; color: #333; }
    .st-Processing { background-color: #17a2b8; }
    .st-Shipped { background-color: #007bff; }
    .st-Completed { background-color: #28a745; }
    .st-Cancelled { background-color: #dc3545; }

    /* Nút hành động nhỏ */
    .btn-action-sm {
        padding: 5px 10px;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
        font-weight: bold;
        color: white;
        margin-right: 5px;
    }
    .btn-approve { background-color: #28a745; } /* Xanh lá */
    .btn-cancel { background-color: #dc3545; }  /* Đỏ */
    .btn-detail { background-color: #6c757d; text-decoration: none; display: inline-block; padding: 5px 10px; border-radius: 3px; color: white; font-size: 12px; font-weight: bold;}
    
    /* Bộ lọc */
    .filter-bar {
        margin-bottom: 20px;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 5px;
        display: flex;
        gap: 15px;
        align-items: center;
    }
    .filter-bar a {
        text-decoration: none;
        color: #007bff;
        font-weight: 500;
    }
    .filter-bar a:hover { text-decoration: underline; }
</style>

<div class="admin-orders-container">
    <h2>Quản lý đơn hàng</h2>

    <div class="filter-bar">
        <span>Lọc nhanh:</span>
        <a href="<?= base_url('index.php?c=admin&a=orders') ?>">Tất cả</a> |
        <a href="<?= base_url('index.php?c=admin&a=orders&status=Pending') ?>">Chờ xử lý</a> |
        <a href="<?= base_url('index.php?c=admin&a=orders&status=Processing') ?>">Đang xử lý</a> |
        <a href="<?= base_url('index.php?c=admin&a=orders&status=Cancelled') ?>">Đã hủy</a>
    </div>

    <table border="1" cellpadding="10" style="width: 100%; border-collapse: collapse; border: 1px solid #eee;">
        <thead style="background: #f8f9fa;">
            <tr>
                <th>ID</th>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Ngày đặt</th>
                <th style="width: 250px;">Hành động</th>
            </tr>
        </thead>
        <tbody>
        <?php if(empty($orders)): ?>
            <tr><td colspan="7" style="text-align: center; padding: 20px; color: #666;">Không tìm thấy đơn hàng nào.</td></tr>
        <?php else: ?>
            <?php foreach ($orders as $o): ?>
                <tr>
                    <td><?= (int)$o['id'] ?></td>
                    <td><strong><?= e($o['code']) ?></strong></td>
                    <td>ID: <?= (int)$o['user_id'] ?></td>
                    <td style="color: #d0021b; font-weight: bold;">
                        <?= number_format($o['total'], 0, ',', '.') ?> đ
                    </td>
                    
                    <td>
                        <span class="status-badge st-<?= e($o['status']) ?>">
                            <?= e($o['status']) ?>
                        </span>
                    </td>
                    
                    <td style="font-size: 13px; color: #666;"><?= e($o['created_at']) ?></td>
                    
                    <td>
                        <a href="<?= base_url('index.php?c=order&a=detail&id='.$o['id']) ?>" target="_blank" class="btn-detail">
                            Xem
                        </a>

                        <?php if ($o['status'] === 'Pending'): ?>
                            
                            <form method="post" action="<?= base_url('index.php?c=admin&a=updateOrderStatus') ?>" style="display: inline-block;">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="status" value="Processing">
                                <button type="submit" class="btn-action-sm btn-approve" onclick="return confirm('Duyệt đơn hàng này?');">
                                    ✓ Duyệt
                                </button>
                            </form>

                            <form method="post" action="<?= base_url('index.php?c=admin&a=updateOrderStatus') ?>" style="display: inline-block;">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="status" value="Cancelled">
                                <button type="submit" class="btn-action-sm btn-cancel" onclick="return confirm('Hủy đơn hàng này?');">
                                    ✕ Hủy
                                </button>
                            </form>

                        <?php elseif ($o['status'] === 'Processing'): ?>
                            <form method="post" action="<?= base_url('index.php?c=admin&a=updateOrderStatus') ?>" style="display: inline-block;">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="status" value="Shipped">
                                <button type="submit" class="btn-action-sm" style="background: #007bff;">
                                    🚛 Giao hàng
                                </button>
                            </form>
                        
                        <?php elseif ($o['status'] === 'Shipped'): ?>
                             <form method="post" action="<?= base_url('index.php?c=admin&a=updateOrderStatus') ?>" style="display: inline-block;">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="status" value="Completed">
                                <button type="submit" class="btn-action-sm" style="background: #28a745;">
                                    ☑ Hoàn tất
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>