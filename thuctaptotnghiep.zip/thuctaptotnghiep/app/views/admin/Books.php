<?php /** @var array $books */ ?>

<style>
    /* CSS Riêng cho trang Admin Books */
    .admin-container {
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
        border-bottom: 2px solid #f1f1f1;
        padding-bottom: 15px;
    }

    .page-title {
        font-size: 24px;
        color: #333;
        margin: 0;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    .btn-add {
        background-color: #28a745;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        transition: 0.3s;
    }
    .btn-add:hover {
        background-color: #218838;
        box-shadow: 0 4px 8px rgba(40, 167, 69, 0.2);
    }

    /* Bảng dữ liệu */
    .table-responsive {
        overflow-x: auto;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 900px;
    }

    .data-table th {
        background-color: #f8f9fa;
        color: #495057;
        font-weight: 700;
        padding: 15px;
        text-align: left;
        border-bottom: 2px solid #dee2e6;
        text-transform: uppercase;
        font-size: 13px;
    }

    .data-table td {
        padding: 12px 15px;
        vertical-align: middle;
        border-bottom: 1px solid #eee;
        color: #555;
        font-size: 14px;
    }

    .data-table tr:hover {
        background-color: #f8f9fa;
    }

    /* Các thành phần trong bảng */
    .book-thumb {
        width: 50px;
        height: 70px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .book-title-cell {
        max-width: 250px;
        line-height: 1.4;
    }
    .book-title-text {
        font-weight: 600;
        color: #333;
        display: block;
        margin-bottom: 4px;
    }
    .discount-tag {
        font-size: 11px;
        color: #dc3545;
        background: #ffe3e3;
        padding: 2px 6px;
        border-radius: 3px;
        font-weight: bold;
    }

    .category-tag {
        display: inline-block;
        background: #e3f2fd;
        color: #0d47a1;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 12px;
        margin-bottom: 4px;
    }

    .price-original {
        text-decoration: line-through;
        color: #999;
        font-size: 12px;
        display: block;
    }
    .price-final {
        color: #d0021b;
        font-weight: bold;
    }

    .stock-badge {
        font-weight: bold;
    }
    .stock-low { color: #dc3545; }
    .stock-ok { color: #28a745; }

    /* Nút hành động */
    .action-links a, .action-links button {
        margin-right: 5px;
        font-size: 13px;
        cursor: pointer;
    }
    .btn-edit {
        color: #007bff;
        font-weight: 600;
        text-decoration: none;
    }
    .btn-edit:hover { text-decoration: underline; }
    
    .btn-delete {
        color: #dc3545;
        background: none;
        border: none;
        padding: 0;
        font-weight: 600;
    }
    .btn-delete:hover { text-decoration: underline; }

</style>

<div class="admin-container">
    
    <div class="page-header">
        <h2 class="page-title">Quản lý sách</h2>
        <a href="<?= base_url('index.php?c=admin&a=bookCreate') ?>" class="btn-add">
            + Thêm sách mới
        </a>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th style="width: 70px;">Ảnh</th>
                    <th>Thông tin sách</th>
                    <th>Thể loại</th>
                    <th>Giá bán</th>
                    <th style="text-align: center;">Kho</th>
                    <th style="text-align: center;">Đã bán</th>
                    <th style="text-align: center;">Đánh giá</th>
                    <th style="text-align: right;">Hành động</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($books as $b): ?>
                <tr>
                    <td>#<?= (int)$b['id'] ?></td>
                    <td>
                        <?php if (!empty($b['cover_url'])): ?>
                            <img src="<?= e($b['cover_url']) ?>" class="book-thumb" alt="Cover">
                        <?php else: ?>
                            <div style="width:50px; height:70px; background:#eee; display:flex; align-items:center; justify-content:center; font-size:10px; color:#999; border-radius:4px;">No IMG</div>
                        <?php endif; ?>
                    </td>
                    
                    <td class="book-title-cell">
                        <span class="book-title-text"><?= e($b['title']) ?></span>
                        <?php if ((int)$b['discount_percent'] > 0): ?>
                            <span class="discount-tag">Giảm <?= (int)$b['discount_percent'] ?>%</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if (!empty($b['category_names'])): ?>
                            <?php 
                                $cats = explode(',', $b['category_names']);
                                foreach($cats as $cat): 
                            ?>
                                <span class="category-tag"><?= e(trim($cat)) ?></span>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <span style="color: #999; font-style: italic; font-size: 12px;">Chưa phân loại</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if ((int)$b['discount_percent'] > 0): ?>
                            <span class="price-original"><?= money($b['price']) ?></span>
                            <span class="price-final"><?= money(book_effective_price($b)) ?></span>
                        <?php else: ?>
                            <span style="font-weight: 600;"><?= money($b['price']) ?></span>
                        <?php endif; ?>
                    </td>
                    
                    <td style="text-align: center;">
                        <?php $stock = (int)$b['stock_qty']; ?>
                        <span class="stock-badge <?= $stock < 5 ? 'stock-low' : 'stock-ok' ?>">
                            <?= $stock ?>
                        </span>
                    </td>

                    <td style="text-align: center; color: #666;">
                        <?= (int)($b['sold_qty'] ?? 0) ?>
                    </td>

                    <td style="text-align: center;">
                        <span style="color: gold;">★</span> 
                        <strong><?= number_format((float)($b['avg_rating'] ?? 0), 1) ?></strong>
                    </td>
                    
                    <td class="action-links" style="text-align: right;">
                        <a href="<?= base_url('index.php?c=admin&a=bookEdit&id=' . $b['id']) ?>" class="btn-edit">Sửa</a>
                        <span style="color: #ddd;">|</span>
                        <form method="post" action="<?= base_url('index.php?c=admin&a=bookDelete') ?>" style="display:inline"
                              onsubmit="return confirm('Bạn chắc chắn muốn xóa sách: <?= e($b['title']) ?>? Hành động này không thể hoàn tác.');">
                            <?= csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                            <button type="submit" class="btn-delete">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>