<style>
    .auth-container {
        max-width: 400px;
        margin: 50px auto;
        background: #fff;
        padding: 40px 35px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', sans-serif;
    }
    .auth-container h2 {
        text-align: center;
        color: #333;
        margin-bottom: 25px;
        font-size: 28px;
        font-weight: 700;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 15px;
        transition: border-color 0.3s;
    }
    .form-control:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
    }
    .btn-login {
        width: 100%;
        padding: 12px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
        margin-top: 10px;
    }
    .btn-login:hover {
        background-color: #0056b3;
    }
    .auth-links {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
        font-size: 14px;
    }
    .auth-links a {
        color: #007bff;
        text-decoration: none;
        font-weight: 500;
    }
    .auth-links a:hover {
        text-decoration: underline;
    }
    .register-link {
        text-align: center;
        margin-top: 25px;
        font-size: 14px;
        color: #666;
        border-top: 1px solid #eee;
        padding-top: 20px;
    }
</style>

<div class="auth-container">
    <h2>Đăng nhập</h2>

    <form method="post" action="<?= base_url('index.php?c=auth&a=loginPost') ?>">
        <?= csrf_field(); ?>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" placeholder="Nhập email của bạn..." required>
        </div>

        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu..." required>
        </div>

        <button type="submit" class="btn-login">Đăng nhập</button>

        <div class="auth-links">
            <a href="<?= base_url('index.php?c=auth&a=forgot') ?>">Quên mật khẩu?</a>
        </div>
    </form>

    <div class="register-link">
        Bạn chưa có tài khoản? 
        <a href="<?= base_url('index.php?c=auth&a=register') ?>">Đăng ký ngay</a>
    </div>
</div>