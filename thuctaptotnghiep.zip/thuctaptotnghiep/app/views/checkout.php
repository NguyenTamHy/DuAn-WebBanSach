<?php
/** @var array $cart */
/** @var float $shipping */
/** @var float $discount */
/** @var float $total */
?>

<style>
    .checkout-container {
        max-width: 1100px;
        margin: 30px auto;
        padding: 0 20px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .checkout-container h2 {
        color: #333;
        margin-bottom: 30px;
        font-size: 26px;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    /* Layout 2 cột */
    .checkout-layout {
        display: flex;
        gap: 40px;
        flex-wrap: wrap;
    }

    .col-left {
        flex: 1; /* Chiếm phần lớn không gian */
        min-width: 300px;
    }

    .col-right {
        flex: 0 0 400px; /* Cột phải cố định độ rộng */
    }

    /* Box chứa thông tin */
    .checkout-box {
        background: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        border: 1px solid #eee;
        margin-bottom: 20px;
    }

    .checkout-box h3 {
        margin-top: 0;
        margin-bottom: 20px;
        font-size: 18px;
        border-bottom: 2px solid #f1f1f1;
        padding-bottom: 10px;
        color: #007bff;
    }

    /* Form Styles */
    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }

    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 15px;
        transition: 0.3s;
    }

    .form-control:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
    }

    textarea.form-control {
        resize: vertical;
        min-height: 80px;
    }

    /* Danh sách sản phẩm (Mini) */
    .order-item-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .order-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid #eee;
    }

    .item-name {
        font-size: 14px;
        color: #333;
        flex: 1;
        padding-right: 10px;
    }

    .item-price {
        font-weight: 600;
        color: #555;
    }

    /* Tổng kết tiền */
    .summary-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        font-size: 15px;
        color: #666;
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid #eee;
        font-size: 20px;
        color: #333;
        font-weight: bold;
    }

    .total-amount {
        color: #d0021b;
    }

    /* Nút đặt hàng */
    .btn-submit {
        width: 100%;
        background-color: #d0021b;
        color: white;
        border: none;
        padding: 15px;
        font-size: 18px;
        font-weight: bold;
        text-transform: uppercase;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 20px;
        transition: 0.3s;
    }

    .btn-submit:hover {
        background-color: #b00;
    }

    /* Info Payment */
    .payment-info {
        background: #e3f2fd;
        padding: 10px;
        border-radius: 5px;
        font-size: 13px;
        color: #0d47a1;
        margin-top: 10px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .checkout-layout { flex-direction: column; }
        .col-right { flex: auto; width: 100%; order: -1; /* Đưa tổng tiền lên đầu trên mobile */ } 
    }
</style>

<div class="checkout-container">
    <h2>Thanh toán đơn hàng</h2>

    <form method="post" action="<?= base_url('index.php?c=checkout&a=placeOrder') ?>">
        <?= csrf_field(); ?>

        <div class="checkout-layout">
            
            <div class="col-left">
                <div class="checkout-box">
                    <h3>1. Thông tin giao hàng</h3>
                    
                    <div class="form-group">
                        <label>Họ và tên người nhận *</label>
                        <input type="text" name="name" class="form-control" placeholder="Ví dụ: Nguyễn Văn A" required>
                    </div>

                    <div class="form-group">
                        <label>Số điện thoại *</label>
                        <input type="text" name="phone" class="form-control" placeholder="Ví dụ: 0901234567" required>
                    </div>

                    <div class="form-group">
                        <label>Địa chỉ nhận hàng *</label>
                        <textarea name="address" class="form-control" rows="3" placeholder="Số nhà, đường, phường/xã, quận/huyện..." required></textarea>
                    </div>
                </div>

                <div class="checkout-box">
                    <h3>2. Phương thức thanh toán</h3>
                    
                    <div class="form-group">
                        <label>Chọn hình thức thanh toán:</label>
                        <select name="payment_method" class="form-control" id="payment_select">
                            <option value="COD">💵 Thanh toán khi nhận hàng (COD)</option>
                            <option value="MOMO">🟣 Ví MoMo (QR Code)</option>
                            <option value="BANK">🏦 Chuyển khoản Ngân hàng</option>
                        </select>
                    </div>

                    <div id="payment_note" class="payment-info" style="display:none;">
                        <strong>Lưu ý:</strong> Vui lòng quét mã QR hoặc chuyển khoản theo thông tin sẽ hiển thị ở trang tiếp theo sau khi bấm Đặt hàng.
                    </div>
                </div>
            </div>

            <div class="col-right">
                <div class="checkout-box">
                    <h3>Đơn hàng của bạn</h3>
                    
                    <ul class="order-item-list">
                        <?php foreach ($cart['lines'] as $line): ?>
                            <li class="order-item">
                                <div class="item-name">
                                    <strong><?= e($line['book']['title']) ?></strong> <br>
                                    <small style="color: #888;">x <?= (int)$line['qty'] ?></small>
                                </div>
                                <div class="item-price">
                                    <?= money($line['line_total']) ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

                    <div class="summary-row">
                        <span>Tạm tính:</span>
                        <span><?= money($cart['subtotal']) ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Phí vận chuyển:</span>
                        <span><?= money($shipping) ?></span>
                    </div>
                    <div class="summary-row" style="color: #28a745;">
                        <span>Giảm giá:</span>
                        <span>-<?= money($discount) ?></span>
                    </div>

                    <div class="total-row">
                        <span>TỔNG CỘNG:</span>
                        <span class="total-amount"><?= money($total) ?></span>
                    </div>

                    <button type="submit" class="btn-submit">
                        ĐẶT HÀNG NGAY
                    </button>
                    
                    <p style="text-align: center; margin-top: 15px; font-size: 13px; color: #666;">
                        (Nhấn "Đặt hàng ngay" đồng nghĩa với việc bạn đồng ý với các điều khoản của chúng tôi)
                    </p>
                </div>
            </div>

        </div>
    </form>
</div>

<script>
    const paymentSelect = document.getElementById('payment_select');
    const paymentNote = document.getElementById('payment_note');

    paymentSelect.addEventListener('change', function() {
        if (this.value === 'MOMO' || this.value === 'BANK') {
            paymentNote.style.display = 'block';
        } else {
            paymentNote.style.display = 'none';
        }
    });
</script>