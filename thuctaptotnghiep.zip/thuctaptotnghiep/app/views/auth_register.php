<style>
    .auth-container {
        max-width: 450px;
        margin: 40px auto;
        background: #fff;
        padding: 40px 35px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', sans-serif;
    }
    .auth-container h2 {
        text-align: center;
        color: #333;
        margin-bottom: 25px;
        font-size: 28px;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        display: block;
        margin-bottom: 6px;
        font-weight: 600;
        color: #555;
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 15px;
        transition: border-color 0.3s;
    }
    .form-control:focus {
        border-color: #28a745;
        outline: none;
        box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }
    .btn-register {
        width: 100%;
        padding: 12px;
        background-color: #28a745; /* Màu xanh lá đặc trưng cho đăng ký */
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 15px;
        transition: 0.3s;
    }
    .btn-register:hover {
        background-color: #218838;
    }
    .auth-footer {
        text-align: center;
        margin-top: 20px;
        font-size: 14px;
        color: #666;
    }
    .auth-footer a {
        color: #28a745;
        font-weight: bold;
        text-decoration: none;
    }
    .auth-footer a:hover {
        text-decoration: underline;
    }
</style>

<div class="auth-container">
    <h2>Đăng ký tài khoản</h2>

    <form method="post" action="<?= base_url('index.php?c=auth&a=registerPost') ?>">
        <?= csrf_field(); ?>

        <div class="form-group">
            <label>Họ và tên</label>
            <input type="text" name="name" class="form-control" placeholder="Ví dụ: Nguyễn Văn A" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" placeholder="vidu@gmail.com" required>
        </div>

        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu..." required>
        </div>

        <div class="form-group">
            <label>Nhập lại mật khẩu</label>
            <input type="password" name="password_confirmation" class="form-control" placeholder="Xác nhận lại mật khẩu..." required>
        </div>

        <button type="submit" class="btn-register">Đăng ký ngay</button>
    </form>

    <div class="auth-footer">
        Bạn đã có tài khoản? <a href="<?= base_url('index.php?c=auth&a=login') ?>">Đăng nhập tại đây</a>
    </div>
</div>