<?php /** @var string $token */ ?>

<style>
    .auth-container {
        max-width: 400px;
        margin: 50px auto;
        background: #fff;
        padding: 40px 30px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', sans-serif;
    }
    .auth-container h2 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }
    .auth-desc {
        text-align: center;
        color: #666;
        margin-bottom: 25px;
        font-size: 14px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 15px;
    }
    .form-control:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
    }
    .btn-reset {
        width: 100%;
        padding: 12px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .btn-reset:hover {
        background-color: #0056b3;
    }
</style>

<div class="auth-container">
    <h2>Đặt lại mật khẩu</h2>
    <p class="auth-desc">Vui lòng nhập mật khẩu mới cho tài khoản của bạn.</p>

    <form method="post" action="<?= base_url('index.php?c=auth&a=resetPost') ?>">
        <?= csrf_field(); ?>
        <input type="hidden" name="token" value="<?= e($token) ?>">

        <div class="form-group">
            <label>Mật khẩu mới</label>
            <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu mới..." required>
        </div>

        <div class="form-group">
            <label>Xác nhận mật khẩu</label>
            <input type="password" name="password_confirmation" class="form-control" placeholder="Nhập lại mật khẩu mới..." required>
        </div>

        <button type="submit" class="btn-reset">Lưu mật khẩu mới</button>
    </form>
</div>