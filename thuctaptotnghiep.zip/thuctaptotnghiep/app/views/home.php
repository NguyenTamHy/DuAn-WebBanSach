<?php
/** @var array $booksByCategory */
/** @var array $discounted */
/** @var array $bestSellers */

// Hàm hỗ trợ tạo slug (giúp link đẹp hơn)
if (!function_exists('slugify_view')) {
    function slugify_view($str) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $str)));
    }
}
?>

<style>
    /* Lớp phủ mờ khi hết hàng */
    .out-of-stock-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.7); /* Màu trắng mờ */
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10;
        pointer-events: none; /* Vẫn cho phép click vào ảnh bên dưới */
    }
    
    /* Chữ "HẾT HÀNG" */
    .out-of-stock-text {
        background: rgba(0, 0, 0, 0.8);
        color: #fff;
        padding: 5px 10px;
        font-weight: bold;
        font-size: 14px;
        border-radius: 4px;
        text-transform: uppercase;
    }

    /* Nút bấm bị vô hiệu hóa */
    button:disabled {
        cursor: not-allowed;
        opacity: 0.7;
    }
</style>

<?php if (!empty($discounted)): ?>
<div class="home-banner" style="margin-bottom: 40px;">
    <h2 style="color: #d0021b; border-bottom: 2px solid #d0021b; padding-bottom: 10px; margin-bottom: 20px;">
        🔥 Sách đang giảm giá sốc
    </h2>
    <div class="book-list">
        <?php foreach ($discounted as $b): ?>
            <div class="book-card" style="position: relative;">
                
                <div class="image-wrapper" style="position: relative; margin-bottom: 10px;">
                    <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="display: block;">
                        <?php if (!empty($b['cover_url'])): ?>
                            <img src="<?= e($b['cover_url']) ?>" alt="" style="height:180px; width: 100%; object-fit: contain;">
                        <?php else: ?>
                            <img src="<?= base_url('assets/images/no-image.png') ?>" style="height:180px; width: 100%; object-fit: contain; background: #eee;">
                        <?php endif; ?>
                    </a>
                    
                    <?php if ((int)$b['stock_qty'] <= 0): ?>
                        <div class="out-of-stock-overlay">
                            <span class="out-of-stock-text">HẾT HÀNG</span>
                        </div>
                    <?php elseif ((int)$b['discount_percent'] > 0): ?>
                        <span class="badge-discount" style="position: absolute; top: 0; right: 0; background: red; color: white; padding: 3px 8px; font-size: 12px; border-radius: 0 0 0 8px; font-weight: bold; z-index: 5;">
                            -<?= (int)$b['discount_percent'] ?>%
                        </span>
                    <?php endif; ?>
                </div>

                <h3 style="font-size: 16px; margin: 0 0 10px 0; height: 40px; overflow: hidden; line-height: 20px;">
                    <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="color: #333;">
                        <?= e($b['title']) ?>
                    </a>
                </h3>

                <div class="price-section" style="display: flex; align-items: baseline; gap: 8px;">
                    <?php if (book_has_discount($b)): ?>
                        <div style="font-size: 16px; color: #d0021b; font-weight: bold;">
                            <?= money(book_effective_price($b)) ?>
                        </div>
                        <div style="font-size: 13px; color: #888; text-decoration: line-through;">
                            <?= money($b['price']) ?>
                        </div>
                    <?php else: ?>
                        <div style="font-size: 16px; color: #000; font-weight: bold;">
                            <?= money($b['price']) ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div style="margin-top: 15px;">
                    <?php if ((int)$b['stock_qty'] > 0): ?>
                        <form method="post" action="<?= base_url('index.php?c=cart&a=add') ?>">
                            <input type="hidden" name="_token" value="dummy">
                            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                            <input type="hidden" name="qty" value="1">
                            <button type="submit" style="width: 100%; background: #007bff; color: white; border: none; padding: 8px; border-radius: 4px; cursor: pointer; font-weight: 500;">
                                Thêm vào giỏ
                            </button>
                        </form>
                    <?php else: ?>
                        <button disabled style="width: 100%; background: #6c757d; color: #fff; border: none; padding: 8px; border-radius: 4px; cursor: not-allowed; font-weight: bold;">
                            Hết hàng
                        </button>
                    <?php endif; ?>
                </div>

            </div>
            <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="category-sections">
    <?php foreach ($booksByCategory as $section): ?>
        <section class="cat-section" style="margin-bottom: 50px;">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px;">
                <h2 style="color: #007bff; margin: 0; font-size: 22px; text-transform: uppercase;">
                    <?= e($section['name']) ?>
                </h2>
                <a href="<?= base_url('index.php?c=category&a=show&slug=' . slugify_view($section['name'])) ?>" 
                   style="font-size: 14px; color: #666; font-style: italic;">
                    Xem thêm >>
                </a>
            </div>

            <div class="book-list">
                <?php foreach ($section['books'] as $b): ?>
                    <div class="book-card" style="position: relative;">
                        <div class="image-wrapper" style="position: relative; margin-bottom: 10px;">
                            <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="display: block;">
                                <?php if (!empty($b['cover_url'])): ?>
                                    <img src="<?= e($b['cover_url']) ?>" alt="" style="height:180px; width: 100%; object-fit: contain;">
                                <?php else: ?>
                                    <img src="<?= base_url('assets/images/no-image.png') ?>" style="height:180px; width: 100%; object-fit: contain; background: #eee;">
                                <?php endif; ?>
                            </a>
                            
                            <?php if ((int)$b['stock_qty'] <= 0): ?>
                                <div class="out-of-stock-overlay">
                                    <span class="out-of-stock-text">HẾT HÀNG</span>
                                </div>
                            <?php elseif ((int)$b['discount_percent'] > 0): ?>
                                <span class="badge-discount" style="position: absolute; top: 0; right: 0; background: red; color: white; padding: 3px 8px; font-size: 12px; border-radius: 0 0 0 8px; font-weight: bold; z-index: 5;">
                                    -<?= (int)$b['discount_percent'] ?>%
                                </span>
                            <?php endif; ?>
                        </div>

                        <h3 style="font-size: 16px; margin: 0 0 10px 0; height: 40px; overflow: hidden; line-height: 20px;">
                            <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="color: #333;">
                                <?= e($b['title']) ?>
                            </a>
                        </h3>

                        <div class="price-section" style="display: flex; align-items: baseline; gap: 8px;">
                            <?php if (book_has_discount($b)): ?>
                                <div style="font-size: 16px; color: #d0021b; font-weight: bold;">
                                    <?= money(book_effective_price($b)) ?>
                                </div>
                                <div style="font-size: 13px; color: #888; text-decoration: line-through;">
                                    <?= money($b['price']) ?>
                                </div>
                            <?php else: ?>
                                <div style="font-size: 16px; color: #000; font-weight: bold;">
                                    <?= money($b['price']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div style="margin-top: 15px;">
                            <?php if ((int)$b['stock_qty'] > 0): ?>
                                <form method="post" action="<?= base_url('index.php?c=cart&a=add') ?>">
                                    <input type="hidden" name="_token" value="dummy">
                                    <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                                    <input type="hidden" name="qty" value="1">
                                    <button type="submit" style="width: 100%; background: #007bff; color: white; border: none; padding: 8px; border-radius: 4px; cursor: pointer; font-weight: 500;">
                                        Thêm vào giỏ
                                    </button>
                                </form>
                            <?php else: ?>
                                <button disabled style="width: 100%; background: #6c757d; color: #fff; border: none; padding: 8px; border-radius: 4px; cursor: not-allowed; font-weight: bold;">
                                    Hết hàng
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        </section>
    <?php endforeach; ?>
</div>