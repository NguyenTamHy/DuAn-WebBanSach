<?php
// app/views/layout.php
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore H&K</title>
    
    <link rel="stylesheet" href="<?= base_url('/assets/css/style.css') ?>">
    
    <style>
        /* =========================================
   1. RESET & GLOBAL STYLES
   ========================================= */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f6f8;
    color: #333;
    line-height: 1.6;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

a {
    text-decoration: none;
    color: inherit;
    transition: 0.3s ease;
}

ul {
    list-style: none;
}

img {
    max-width: 100%;
    display: block;
}

/* =========================================
   2. HEADER STYLES (FULL WIDTH)
   ========================================= */
header {
    background: #007bff; /* Màu xanh chuẩn */
    color: #fff;
    padding: 0 40px; /* Padding 2 bên vừa phải */
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    width: 100%; /* Tràn màn hình */
}

header h1 a {
    font-size: 28px;
    font-weight: 800;
    color: #fff;
    letter-spacing: 1px;
}

header nav {
    display: flex;
    align-items: center;
    gap: 20px;
}

header nav a {
    color: rgba(255, 255, 255, 0.9);
    font-weight: 500;
    padding: 8px 12px;
}

header nav a:hover {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    color: #fff;
}

/* =========================================
   3. MAIN CONTENT (FULL WIDTH)
   ========================================= */
main {
    width: 100%;
    max-width: 100%; /* Cho phép tràn màn hình */
    margin: 30px 0;
    padding: 0 40px; /* Cách lề 2 bên để không dính sát */
    flex: 1; /* Đẩy footer xuống đáy */
}

/* =========================================
   4. BOOK LIST (GRID LAYOUT - NẰM NGANG)
   ========================================= */
.book-list {
    display: grid;
    /* Tự động chia cột: Tối thiểu 220px mỗi cuốn */
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); 
    gap: 25px; /* Khoảng cách giữa các sách */
    margin-top: 20px;
    width: 100%;
}

.book-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 15px;
    display: flex;
    flex-direction: column;
    transition: transform 0.2s, box-shadow 0.2s;
    height: 100%;
    position: relative; /* Để định vị nhãn giảm giá/hết hàng */
}

.book-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    border-color: #007bff;
}

.book-card img {
    width: 100%;
    height: 200px;
    object-fit: contain; /* Giữ tỷ lệ ảnh đẹp */
    margin-bottom: 15px;
}

.book-card h3 {
    font-size: 16px;
    margin-bottom: 10px;
    line-height: 1.4;
    height: 44px; /* Giới hạn chiều cao tên sách */
    overflow: hidden;
}

/* Nút bấm trong thẻ sách */
.book-card button {
    margin-top: auto; /* Đẩy nút xuống đáy thẻ */
    cursor: pointer;
}

/* =========================================
   5. FOOTER STYLES (FULL WIDTH)
   ========================================= */
.site-footer {
    background-color: #007bff;
    color: #ffffff;
    padding: 50px 0 20px 0;
    margin-top: auto;
    font-size: 15px;
    width: 100%;
}

.footer-container {
    width: 100%;
    max-width: 100%; /* Tràn màn hình */
    padding: 0 40px; /* Canh lề đồng bộ với Header/Main */
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    text-align: center; /* Căn giữa nội dung */
}

.footer-col {
    flex: 1;
    min-width: 200px;
    margin-bottom: 20px;
    padding: 0 10px;
}

.footer-col h3, .footer-col h4 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 20px;
    text-transform: uppercase;
    color: #fff;
}

.footer-col h3 { font-size: 24px; }

.footer-col p { margin-bottom: 10px; color: #e3f2fd; }

.footer-col ul li { margin-bottom: 10px; }
.footer-col ul li a { color: #e3f2fd; }
.footer-col ul li a:hover { color: #fff; text-decoration: underline; }

.footer-bottom {
    border-top: 1px solid rgba(255, 255, 255, 0.3);
    margin-top: 30px;
    padding-top: 20px;
    text-align: center;
    font-size: 13px;
    color: #e3f2fd;
}

/* =========================================
   6. RESPONSIVE (MOBILE)
   ========================================= */
@media (max-width: 768px) {
    header {
        flex-direction: column;
        height: auto;
        padding: 15px 20px;
        gap: 15px;
    }
    
    header nav {
        flex-wrap: wrap;
        justify-content: center;
    }

    main, .footer-container {
        padding: 0 20px; /* Giảm lề trên mobile */
    }

    .footer-container {
        flex-direction: column;
    }
    
    .book-list {
        grid-template-columns: repeat(2, 1fr); /* 2 cột trên mobile */
        gap: 15px;
    }
}

@media (max-width: 480px) {
    .book-list {
        grid-template-columns: 1fr; /* 1 cột trên màn hình rất nhỏ */
    }
}
    </style>
</head>
<body>

<header>
    <header>
    <h1><a href="<?= base_url('index.php') ?>">H&K</a></h1>

    <div class="search-container" style="flex: 1; margin: 0 20px; max-width: 400px;">
        <form action="<?= base_url('index.php') ?>" method="get" style="display: flex;">
            <input type="hidden" name="c" value="home">
            <input type="hidden" name="a" value="search">
            <input type="text" name="keyword" placeholder="Tìm sách..." 
                   value="<?= e($_GET['keyword'] ?? '') ?>"
                   style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px 0 0 4px;">
            <button type="submit" style="padding: 8px 15px; background: #0056b3; color: #fff; border: none; border-radius: 0 4px 4px 0; cursor: pointer;">
                Tìm
            </button>
        </form>
    </div>

    <nav>
        <a href="<?= base_url('index.php') ?>">Trang chủ</a>
        <a href="<?= base_url('index.php?c=cart&a=index') ?>">Giỏ hàng</a>
        
        <?php if (is_logged_in()): ?>
            <span>Xin chào, <?= e(current_user_name() ?? '') ?></span>
            <a href="<?= base_url('index.php?c=order&a=my') ?>">Đơn hàng</a>
            <?php if (is_admin()): ?>
                <a href="<?= base_url('index.php?c=admin&a=index') ?>">Admin</a>
            <?php endif; ?>
            <a href="<?= base_url('index.php?c=auth&a=logout') ?>">Đăng xuất</a>
        <?php else: ?>
            <a href="<?= base_url('index.php?c=auth&a=login') ?>">Đăng nhập</a>
        <?php endif; ?>
    </nav>
</header>
</header>

<main>
    <?php if (!empty($_SESSION['message'])): ?>
        <div style="background:#d4edda; color:#155724; padding:10px; margin-bottom:15px; border-radius:4px;">
            <?= e($_SESSION['message']); unset($_SESSION['message']); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <div style="background:#f8d7da; color:#721c24; padding:10px; margin-bottom:15px; border-radius:4px;">
            <?= e($_SESSION['error']); unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($viewFile)) include $viewFile; ?>
</main>

<footer class="site-footer">
    <div class="footer-container">
        
        <div class="footer-col">
            <h3>H&K</h3>
            <p>Website demo đồ án - bán sách trực tuyến.</p>
            <p>Đọc sách mỗi ngày, mở mang tri thức.</p>
        </div>

        <div class="footer-col">
            <h4>Danh mục</h4>
            <ul>
                <li><a href="#">Văn học</a></li>
                <li><a href="#">Thiếu nhi</a></li>
                <li><a href="#">Kinh tế</a></li>
                <li><a href="#">Tâm lý - Kỹ năng</a></li>
                <li><a href="#">Tất cả sách</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Chính sách</h4>
            <ul>
                <li><a href="#">Chính sách giao hàng</a></li>
                <li><a href="#">Đổi trả & Hoàn tiền</a></li>
                <li><a href="#">Chính sách bảo mật</a></li>
                <li><a href="#">Điều khoản sử dụng</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Liên hệ</h4>
            <p>Hotline: 0889125856</p>
            <p>Email: HnK@gmail.com</p>
            <p>Địa chỉ: Số 2 Võ Oanh, P.Thạnh Mỹ Tây, TP. HCM</p>
        </div>

    </div>

    <div class="footer-bottom">
        <p>&copy; 2025 Bookstore - H&K Team. All rights reserved.</p>
        <p>&copy; 2025 H&K</p>
    </div>
</footer>

</body>
</html>