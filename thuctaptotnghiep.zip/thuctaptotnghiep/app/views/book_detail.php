<?php
/** @var array $book */
/** @var array $related */
/** @var array $reviews */
/** @var float $avgRating */
?>

<style>
    .book-detail-container {
        display: flex;
        gap: 40px;
        margin-top: 20px;
        flex-wrap: wrap;
    }

    .book-image-col {
        flex: 0 0 320px; /* Cột ảnh cố định */
        position: relative;
    }

    .book-info-col {
        flex: 1; /* Cột thông tin tự giãn */
        min-width: 300px;
    }

    .book-cover-large {
        width: 100%;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border: 1px solid #eee;
        object-fit: contain;
        background: #fff;
    }

    .book-title {
        font-size: 28px;
        margin-bottom: 15px;
        color: #333;
        line-height: 1.3;
    }

    .book-price-box {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .current-price {
        font-size: 32px;
        color: #d0021b;
        font-weight: bold;
    }

    .old-price {
        color: #888;
        text-decoration: line-through;
        font-size: 16px;
        margin-left: 10px;
    }

    .discount-badge {
        background: #d0021b;
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 14px;
        vertical-align: middle;
        margin-left: 5px;
    }

    .stock-status {
        margin-bottom: 15px;
        font-size: 16px;
    }

    .status-in-stock { color: #28a745; font-weight: bold; }
    .status-out-stock { color: #dc3545; font-weight: bold; }

    .book-desc {
        line-height: 1.6;
        color: #555;
        margin-bottom: 25px;
        border-top: 1px solid #eee;
        padding-top: 15px;
    }

    /* Form mua hàng */
    .buy-form {
        display: flex;
        gap: 15px;
        align-items: center;
        margin-top: 20px;
    }

    .qty-input-large {
        width: 80px;
        padding: 10px;
        text-align: center;
        font-size: 18px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .btn-buy-now {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 12px 40px;
        font-size: 18px;
        font-weight: bold;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }

    .btn-buy-now:hover { background-color: #0056b3; }

    .btn-disabled-large {
        background-color: #6c757d;
        color: white;
        border: none;
        padding: 12px 40px;
        font-size: 18px;
        font-weight: bold;
        border-radius: 5px;
        cursor: not-allowed;
    }

    /* Phần Review */
    .review-section, .related-section {
        margin-top: 50px;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        border: 1px solid #eee;
    }

    .section-title {
        font-size: 20px;
        border-bottom: 2px solid #007bff;
        padding-bottom: 10px;
        margin-bottom: 20px;
        color: #333;
    }

    .review-item {
        border-bottom: 1px solid #eee;
        padding: 15px 0;
    }
    .review-item:last-child { border-bottom: none; }

    /* Mobile */
    @media (max-width: 768px) {
        .book-detail-container { flex-direction: column; }
        .book-image-col { width: 100%; text-align: center; }
        .book-cover-large { max-width: 300px; }
        .buy-form { flex-direction: column; align-items: flex-start; }
        .btn-buy-now { width: 100%; }
    }
</style>

<div class="book-detail-container">
    <div class="book-image-col">
        <?php if (!empty($book['cover_url'])): ?>
            <img src="<?= e($book['cover_url']) ?>" class="book-cover-large" alt="<?= e($book['title']) ?>">
        <?php else: ?>
            <img src="<?= base_url('assets/images/no-image.png') ?>" class="book-cover-large" style="padding: 50px; background: #eee;">
        <?php endif; ?>
    </div>

    <div class="book-info-col">
        <h1 class="book-title"><?= e($book['title']) ?></h1>
        
        <p style="color: #666; font-size: 14px;">
            Đánh giá: <span style="color: gold; font-size: 16px;">★</span> <strong><?= number_format($avgRating, 1) ?>/5</strong> 
            (<?= count($reviews) ?> lượt đánh giá)
        </p>

        <div class="book-price-box">
            <?php if (book_has_discount($book)): ?>
                <span class="current-price"><?= money(book_effective_price($book)) ?></span>
                <span class="old-price"><?= money($book['price']) ?></span>
                <span class="discount-badge">-<?= (int)$book['discount_percent'] ?>%</span>
            <?php else: ?>
                <span class="current-price"><?= money($book['price']) ?></span>
            <?php endif; ?>
        </div>

        <div class="stock-status">
            Tình trạng: 
            <?php if ((int)$book['stock_qty'] > 0): ?>
                <span class="status-in-stock">✔ Còn hàng (<?= (int)$book['stock_qty'] ?> bản)</span>
            <?php else: ?>
                <span class="status-out-stock">✖ Hết hàng</span>
            <?php endif; ?>
        </div>

        <div class="book-desc">
            <strong>Giới thiệu sách:</strong><br>
            <?= nl2br(e($book['description'] ?? 'Chưa có mô tả cho cuốn sách này.')) ?>
        </div>

        <?php if ((int)$book['stock_qty'] > 0): ?>
            <form method="post" action="<?= base_url('index.php?c=cart&a=add') ?>" class="buy-form">
                <?= csrf_field(); ?>
                <input type="hidden" name="book_id" value="<?= (int)$book['id'] ?>">
                
                <div>
                    <label style="font-weight: 600; display: block; margin-bottom: 5px;">Số lượng:</label>
                    <input type="number" name="qty" value="1" min="1" max="<?= (int)$book['stock_qty'] ?>" 
                           class="qty-input-large" required>
                </div>
                
                <div style="flex-grow: 1;">
                    <label style="visibility: hidden; display: block; margin-bottom: 5px;">Mua:</label>
                    <button type="submit" class="btn-buy-now">
                        🛒 THÊM VÀO GIỎ
                    </button>
                </div>
            </form>
        <?php else: ?>
            <div style="margin-top: 20px;">
                <button disabled class="btn-disabled-large">
                    HẾT HÀNG
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="review-section">
    <h3 class="section-title">Đánh giá & Bình luận</h3>

    <?php if (is_logged_in()): ?>
        <form method="post" action="<?= base_url('index.php?c=book&a=reviewPost') ?>" style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <?= csrf_field(); ?>
            <input type="hidden" name="book_id" value="<?= (int)$book['id'] ?>">
            
            <div style="margin-bottom: 10px;">
                <strong>Bạn chấm mấy sao?</strong>
                <select name="rating" style="padding: 5px; margin-left: 10px;">
                    <option value="5">5 Sao (Tuyệt vời)</option>
                    <option value="4">4 Sao (Tốt)</option>
                    <option value="3">3 Sao (Bình thường)</option>
                    <option value="2">2 Sao (Tệ)</option>
                    <option value="1">1 Sao (Rất tệ)</option>
                </select>
            </div>
            
            <textarea name="comment" rows="3" placeholder="Viết cảm nhận của bạn về sách này..." style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
            
            <button type="submit" style="background: #007bff; color: white; border: none; padding: 8px 20px; border-radius: 4px; cursor: pointer;">Gửi đánh giá</button>
        </form>
    <?php else: ?>
        <p style="margin-bottom: 20px;">Vui lòng <a href="<?= base_url('index.php?c=auth&a=login') ?>" style="color: #007bff; font-weight: bold;">Đăng nhập</a> để viết đánh giá.</p>
    <?php endif; ?>

    <?php if(empty($reviews)): ?>
        <p style="color: #666; font-style: italic;">Chưa có đánh giá nào.</p>
    <?php else: ?>
        <?php foreach ($reviews as $r): ?>
            <div class="review-item">
                <div style="display: flex; justify-content: space-between;">
                    <strong><?= e($r['user_name'] ?? 'Ẩn danh') ?></strong>
                    <span style="color: #ccc; font-size: 13px;"><?= date('d/m/Y', strtotime($r['created_at'])) ?></span>
                </div>
                <div style="color: gold; margin: 5px 0;">
                    <?= str_repeat('★', (int)$r['rating']) ?><?= str_repeat('☆', 5 - (int)$r['rating']) ?>
                </div>
                <p style="margin: 0; color: #444;"><?= nl2br(e($r['comment'] ?? '')) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="related-section">
    <h3 class="section-title">Sách cùng thể loại</h3>
    <div class="book-list">
        <?php foreach ($related as $b): ?>
            <?php if ($b['id'] == $book['id']) continue; ?>
            <div class="book-card">
                <div style="position: relative; margin-bottom: 10px;">
                    <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>">
                        <?php if (!empty($b['cover_url'])): ?>
                            <img src="<?= e($b['cover_url']) ?>" style="height:150px; width: 100%; object-fit: contain;">
                        <?php else: ?>
                             <img src="<?= base_url('assets/images/no-image.png') ?>" style="height:150px; width: 100%; object-fit: contain; background: #eee;">
                        <?php endif; ?>
                    </a>
                    <?php if ((int)$b['discount_percent'] > 0): ?>
                        <span style="position: absolute; top: 0; right: 0; background: red; color: white; padding: 2px 5px; font-size: 10px; border-radius: 0 0 0 5px; font-weight: bold;">
                            -<?= (int)$b['discount_percent'] ?>%
                        </span>
                    <?php endif; ?>
                </div>
                
                <h4 style="font-size: 14px; margin: 5px 0; height: 36px; overflow: hidden;">
                    <a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>" style="color: #333; text-decoration: none;">
                        <?= e($b['title']) ?>
                    </a>
                </h4>
                
                <div style="margin-top: 5px;">
                    <strong style="color: #d0021b;"><?= money(book_effective_price($b)) ?></strong>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>