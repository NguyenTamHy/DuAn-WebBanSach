<style>
    .auth-container {
        max-width: 400px;
        margin: 50px auto;
        background: #fff;
        padding: 40px 30px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', sans-serif;
    }
    .auth-container h2 {
        text-align: center;
        color: #333;
        margin-bottom: 15px;
        font-size: 26px;
    }
    .auth-desc {
        text-align: center;
        color: #666;
        margin-bottom: 25px;
        font-size: 14px;
        line-height: 1.5;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 15px;
        transition: 0.3s;
    }
    .form-control:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
    }
    .btn-auth {
        width: 100%;
        padding: 12px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .btn-auth:hover {
        background-color: #0056b3;
    }
    .auth-link {
        text-align: center;
        margin-top: 20px;
        display: block;
        color: #007bff;
        text-decoration: none;
        font-size: 14px;
    }
    .auth-link:hover {
        text-decoration: underline;
    }
</style>

<div class="auth-container">
    <h2>Quên mật khẩu?</h2>
    <p class="auth-desc">Đừng lo lắng! Hãy nhập email bạn đã đăng ký, chúng tôi sẽ gửi hướng dẫn đặt lại mật khẩu cho bạn.</p>

    <form method="post" action="<?= base_url('index.php?c=auth&a=forgotPost') ?>">
        <?= csrf_field(); ?>

        <div class="form-group">
            <label>Email của bạn</label>
            <input type="email" name="email" class="form-control" placeholder="vidu@gmail.com" required>
        </div>

        <button type="submit" class="btn-auth">Gửi yêu cầu</button>
    </form>

    <a href="<?= base_url('index.php?c=auth&a=login') ?>" class="auth-link">
        &larr; Quay lại trang Đăng nhập
    </a>
</div>