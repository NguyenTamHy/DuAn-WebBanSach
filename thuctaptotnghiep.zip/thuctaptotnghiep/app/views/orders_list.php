<?php /** @var array $orders */ ?>

<style>
    .orders-container {
        max-width: 1100px;
        margin: 30px auto;
        padding: 0 20px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .orders-container h2 {
        color: #333;
        margin-bottom: 25px;
        font-size: 24px;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    .empty-alert {
        background-color: #f8f9fa;
        padding: 30px;
        border-radius: 8px;
        text-align: center;
        color: #666;
        border: 1px dashed #ccc;
        font-size: 16px;
    }

    /* Bảng responsive */
    .table-responsive {
        width: 100%;
        overflow-x: auto;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        border-radius: 10px;
        background: #fff;
        border: 1px solid #eee;
    }

    .order-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 700px; /* Đảm bảo không bị co quá nhỏ trên mobile */
    }

    .order-table th {
        background-color: #f1f3f5;
        color: #495057;
        padding: 18px 15px;
        text-align: left;
        font-weight: 700;
        font-size: 14px;
        text-transform: uppercase;
        border-bottom: 2px solid #dee2e6;
    }

    .order-table td {
        padding: 15px;
        border-bottom: 1px solid #eee;
        color: #555;
        vertical-align: middle;
        font-size: 15px;
    }

    .order-table tr:hover {
        background-color: #f8f9fa;
    }

    .order-table td.total-col {
        font-weight: bold;
        color: #d63031;
    }

    .order-table td.status-col {
        font-weight: 600;
    }

    /* Nút Xem chi tiết */
    .btn-view {
        display: inline-block;
        padding: 8px 16px;
        background-color: #e3f2fd;
        color: #007bff;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s ease;
        text-decoration: none;
        border: 1px solid transparent;
    }

    .btn-view:hover {
        background-color: #007bff;
        color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 123, 255, 0.2);
    }

    /* Mobile */
    @media (max-width: 768px) {
        .orders-container {
            padding: 0 10px;
        }
    }
</style>

<div class="orders-container">
    <h2>Đơn hàng của tôi</h2>

    <?php if (empty($orders)): ?>
        <div class="empty-alert">
            <p>Bạn chưa có đơn hàng nào.</p>
            <div style="margin-top: 15px;">
                <a href="<?= base_url('index.php') ?>" style="color: #007bff; text-decoration: underline;">Quay lại mua sắm ngay</a>
            </div>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="order-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>Mã đơn</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th>Ngày đặt</th>
                        <th style="text-align: center;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $o): ?>
                        <tr>
                            <td>#<?= (int)$o['id'] ?></td>
                            <td>
                                <strong style="color: #333;"><?= e($o['code']) ?></strong>
                            </td>
                            <td class="total-col"><?= number_format($o['total'], 0, ',', '.') ?> đ</td>
                            
                            <td class="status-col">
                                <?php 
                                    $st = $o['status'];
                                    $color = '#6c757d'; // Mặc định màu xám
                                    $text = $st;

                                    if($st == 'Pending') { 
                                        $color = '#ffc107'; // Vàng
                                        $text = '⏳ Chờ xử lý';
                                    }
                                    elseif($st == 'Completed') { 
                                        $color = '#28a745'; // Xanh lá
                                        $text = '✅ Hoàn thành';
                                    }
                                    elseif($st == 'Cancelled') { 
                                        $color = '#dc3545'; // Đỏ
                                        $text = '❌ Đã hủy';
                                    }
                                    elseif($st == 'Shipped') { 
                                        $color = '#17a2b8'; // Xanh dương
                                        $text = '🚛 Đang giao';
                                    }
                                    elseif($st == 'Processing') { 
                                        $color = '#007bff'; // Xanh biển
                                        $text = '📦 Đang đóng gói';
                                    }
                                ?>
                                <span style="color: <?= $color ?>"><?= $text ?></span>
                            </td>
                            
                            <td style="color: #666;">
                                <?= date('d/m/Y H:i', strtotime($o['created_at'])) ?>
                            </td>
                            
                            <td style="text-align: center;">
                                <a href="<?= base_url('index.php?c=order&a=detail&id='.$o['id']) ?>" class="btn-view">
                                    Xem chi tiết
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>