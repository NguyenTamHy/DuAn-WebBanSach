<?php /** @var array $cart */ ?>

<style>
    .cart-container {
        max-width: 1100px;
        margin: 30px auto;
        padding: 0 20px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .cart-container h2 {
        color: #333;
        margin-bottom: 25px;
        font-size: 24px;
        border-left: 5px solid #007bff;
        padding-left: 15px;
    }

    /* Bảng giỏ hàng */
    .table-responsive {
        overflow-x: auto;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        background: #fff;
        border: 1px solid #eee;
        margin-bottom: 20px;
    }

    .cart-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 700px;
    }

    .cart-table th {
        background-color: #f8f9fa;
        padding: 15px;
        text-align: left;
        font-weight: 700;
        color: #555;
        border-bottom: 2px solid #dee2e6;
    }

    .cart-table td {
        padding: 15px;
        vertical-align: middle;
        border-bottom: 1px solid #eee;
        color: #333;
    }

    /* Cột sản phẩm (Ảnh + Tên) */
    .product-col {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .product-img {
        width: 50px;
        height: 70px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .product-title {
        font-weight: 600;
        font-size: 15px;
        color: #007bff;
    }

    /* Input số lượng */
    .qty-input {
        width: 60px;
        padding: 8px;
        text-align: center;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }

    /* Tổng tiền */
    .line-total {
        font-weight: bold;
        color: #d63031;
    }

    /* Khu vực tổng kết và nút bấm */
    .cart-summary {
        background: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
    }

    .cart-total {
        font-size: 20px;
        color: #333;
    }

    .cart-total strong {
        color: #d0021b;
        font-size: 24px;
    }

    .cart-actions {
        display: flex;
        gap: 10px;
    }

    /* Nút bấm chung */
    .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        font-size: 14px;
        transition: 0.3s;
        display: inline-block;
    }

    .btn-update {
        background-color: #17a2b8;
        color: white;
    }
    .btn-update:hover { background-color: #138496; }

    .btn-checkout {
        background-color: #28a745;
        color: white;
    }
    .btn-checkout:hover { background-color: #218838; }

    .btn-clear {
        background-color: #dc3545;
        color: white;
    }
    .btn-clear:hover { background-color: #c82333; }

    /* Empty state */
    .empty-cart {
        text-align: center;
        padding: 40px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }
    .empty-cart a { color: #007bff; text-decoration: underline; }
</style>

<div class="cart-container">
    <h2>Giỏ hàng của bạn</h2>

    <?php if (empty($cart['lines'])): ?>
        <div class="empty-cart">
            <p style="font-size: 18px; color: #666;">Giỏ hàng của bạn đang trống.</p>
            <a href="<?= base_url('index.php') ?>">Quay lại trang chủ để mua sắm</a>
        </div>
    <?php else: ?>
        
        <form method="post" action="<?= base_url('index.php?c=cart&a=update') ?>">
            <?= csrf_field(); ?>
            
            <div class="table-responsive">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th style="width: 45%;">Sản phẩm</th>
                            <th style="width: 15%;">Đơn giá</th>
                            <th style="width: 15%; text-align: center;">Số lượng</th>
                            <th style="width: 25%; text-align: right;">Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart['lines'] as $line): ?>
                            <tr>
                                <td>
                                    <div class="product-col">
                                        <?php if (!empty($line['book']['cover_url'])): ?>
                                            <img src="<?= e($line['book']['cover_url']) ?>" class="product-img" alt="Bìa sách">
                                        <?php else: ?>
                                            <div style="width:50px; height:70px; background:#eee; display:flex; align-items:center; justify-content:center; font-size:10px; color:#999;">No IMG</div>
                                        <?php endif; ?>
                                        
                                        <div>
                                            <div class="product-title"><?= e($line['book']['title']) ?></div>
                                            <?php if((int)$line['book']['discount_percent'] > 0): ?>
                                                <small style="color: #dc3545;">Giảm <?= (int)$line['book']['discount_percent'] ?>%</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?= money($line['unit_price']) ?></td>
                                <td style="text-align: center;">
                                    <input type="number" class="qty-input" 
                                           name="qty[<?= $line['book']['id'] ?>]"
                                           value="<?= $line['qty'] ?>" min="0">
                                </td>
                                <td style="text-align: right;" class="line-total">
                                    <?= money($line['line_total']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="cart-summary">
                <div>
                    </div>

                <div style="text-align: right;">
                    <div class="cart-total" style="margin-bottom: 15px;">
                        Tổng cộng: <strong><?= money($cart['subtotal']) ?></strong>
                    </div>
                    <div class="cart-actions">
                        <button type="submit" class="btn btn-update">Cập nhật giỏ hàng</button>
                        <a href="<?= base_url('index.php?c=checkout&a=index') ?>" class="btn btn-checkout">Tiến hành thanh toán</a>
                    </div>
                </div>
            </div>
        </form>

        <div style="margin-top: 20px;">
            <form method="post" action="<?= base_url('index.php?c=cart&a=clear') ?>" onsubmit="return confirm('Bạn có chắc chắn muốn xóa toàn bộ giỏ hàng?');">
                <?= csrf_field(); ?>
                <button type="submit" class="btn btn-clear">🗑️ Xóa toàn bộ giỏ hàng</button>
            </form>
        </div>

    <?php endif; ?>
</div>