<?php
/** @var array $order */
/** @var array $items */
// Lấy thông tin địa chỉ từ JSON
$addr = json_decode($order['addr_json'] ?? '{}', true) ?: [];
?>

<h2>Chi tiết đơn hàng #<?= e($order['code']) ?></h2>
<p>Ngày đặt: <?= e($order['created_at']) ?></p>

<p style="font-size: 16px;">
    Trạng thái: 
    <?php if ($order['status'] === 'Pending'): ?>
        <span style="color: #ffc107; font-weight: bold;">⏳ Chờ xử lý</span>
    <?php elseif ($order['status'] === 'Cancelled'): ?>
        <span style="color: #dc3545; font-weight: bold;">❌ Đã hủy</span>
    <?php elseif ($order['status'] === 'Completed'): ?>
        <span style="color: #28a745; font-weight: bold;">✅ Hoàn thành</span>
    <?php elseif ($order['status'] === 'Shipped'): ?>
        <span style="color: #007bff; font-weight: bold;">🚛 Đang giao</span>
    <?php else: ?>
        <?= e($order['status']) ?>
    <?php endif; ?>
</p>

<p>Thanh toán: <strong><?= e($order['payment_method']) ?></strong></p>

<?php if ($order['status'] === 'Pending'): ?>
    <div style="margin: 20px 0; padding: 15px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 5px;">
        <p style="margin-top: 0; margin-bottom: 10px; color: #856404; font-size: 14px;">
            <i>Nếu muốn thay đổi ý định, bạn có thể hủy đơn hàng này ngay bây giờ.</i>
        </p>
        
        <form method="post" action="<?= base_url('index.php?c=order&a=cancel') ?>" 
              onsubmit="return confirm('Bạn chắc chắn muốn hủy đơn hàng này? Hành động này không thể hoàn tác.');">
            
            <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
            
            <button type="submit" style="background: #dc3545; color: #fff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold;">
                Hủy Đơn Hàng
            </button>
        </form>
    </div>
<?php endif; ?>

<hr>

<h3>Thông tin người nhận</h3>
<ul style="list-style: none; padding: 0;">
    <li><strong>Họ tên:</strong> <?= e($addr['name'] ?? '') ?></li>
    <li><strong>Điện thoại:</strong> <?= e($addr['phone'] ?? '') ?></li>
    <li><strong>Địa chỉ:</strong> <?= e($addr['address'] ?? '') ?></li>
</ul>

<h3>Sản phẩm</h3>
<table border="1" cellpadding="10" style="width: 100%; border-collapse: collapse;">
    <thead style="background: #f8f9fa;">
        <tr>
            <th style="text-align: left;">Sách</th>
            <th style="text-align: center;">SL</th>
            <th style="text-align: right;">Đơn giá</th>
            <th style="text-align: right;">Thành tiền</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($items as $it): ?>
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <?php if (!empty($it['cover_url'])): ?>
                            <img src="<?= e($it['cover_url']) ?>" style="width: 40px; height: 55px; object-fit: cover; border: 1px solid #ddd;">
                        <?php endif; ?>
                        <span><?= e($it['title']) ?></span>
                    </div>
                </td>
                <td style="text-align: center;"><?= (int)$it['qty'] ?></td>
                <td style="text-align: right;"><?= money($it['price']) ?></td>
                <td style="text-align: right; font-weight: bold;"><?= money($it['price'] * $it['qty']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div style="text-align: right; margin-top: 20px; border-top: 2px solid #eee; padding-top: 15px;">
    <p>Tạm tính: <?= money($order['subtotal']) ?></p>
    <p>Phí ship: <?= money($order['shipping_fee']) ?></p>
    <p>Giảm giá: -<?= money($order['discount']) ?></p>
    <p style="font-size: 20px; color: #d0021b; margin-top: 10px;">
        <strong>Tổng cộng: <?= money($order['total']) ?></strong>
    </p>
</div>

<div style="margin-top: 30px;">
    <a href="<?= base_url('index.php?c=order&a=my') ?>" style="text-decoration: none; color: #007bff; font-weight: 500;">
        &larr; Quay lại danh sách đơn hàng
    </a>
</div>