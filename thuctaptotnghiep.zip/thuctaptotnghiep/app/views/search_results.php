<?php 
// app/views/search_results.php
/** @var array $books */
/** @var string $keyword */
?>
<h2>Kết quả tìm kiếm cho: "<?= e($keyword) ?>"</h2>

<?php if (empty($books)): ?>
    <p>Không tìm thấy sách nào phù hợp.</p>
<?php else: ?>
    <div class="book-list"> <?php foreach ($books as $b): ?>
            <div class="book-card">
                <?php if (!empty($b['cover_url'])): ?>
                    <img src="<?= e($b['cover_url']) ?>" alt="" style="height:120px;">
                <?php endif; ?>
                <h3><a href="<?= base_url('index.php?c=book&a=detail&id=' . $b['id']) ?>"><?= e($b['title']) ?></a></h3>
                <p>Giá: 
                    <?php if (book_has_discount($b)): ?>
                        <del><?= money($b['price']) ?></del>
                        <strong><?= money(book_effective_price($b)) ?></strong>
                    <?php else: ?>
                        <strong><?= money($b['price']) ?></strong>
                    <?php endif; ?>
                </p>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>