<?php
// app/Mailer.php

require_once __DIR__ . '/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';

function sendResetEmail(string $username, string $email, string $link): bool
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();

        if (MAIL_DRIVER === 'gmail') {
            $mail->Host       = MAIL_HOST_GMAIL;
            $mail->SMTPAuth   = true;
            $mail->Username   = MAIL_USER_GMAIL;
            $mail->Password   = MAIL_PASS_GMAIL;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = MAIL_PORT_GMAIL;
            $fromEmail        = MAIL_FROM_EMAIL_GMAIL;
            $fromName         = MAIL_FROM_NAME_GMAIL;
        } else {
            $mail->Host       = MAIL_HOST_MAILTRAP;
            $mail->SMTPAuth   = true;
            $mail->Username   = MAIL_USER_MAILTRAP;
            $mail->Password   = MAIL_PASS_MAILTRAP;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = MAIL_PORT_MAILTRAP;
            $fromEmail        = MAIL_FROM_EMAIL_MAILTRAP;
            $fromName         = MAIL_FROM_NAME_MAILTRAP;
        }

        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = 'Đặt lại mật khẩu tài khoản Bookstore';
        $mail->Body = "
            <h3>Chào {$username},</h3>
            <p>Bạn đã yêu cầu đặt lại mật khẩu. Nhấn vào liên kết dưới đây để tiếp tục:</p>
            <p><a href=\"{$link}\">{$link}</a></p>
            <p>Liên kết có hiệu lực trong 1 giờ.</p>
        ";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mail error: ' . $mail->ErrorInfo);
        return false;
    }
}
